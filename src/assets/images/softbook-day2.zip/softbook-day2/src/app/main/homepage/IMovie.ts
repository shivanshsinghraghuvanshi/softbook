interface IMovie {
  id: number;
  name: string;
  isAdded: boolean;
}
