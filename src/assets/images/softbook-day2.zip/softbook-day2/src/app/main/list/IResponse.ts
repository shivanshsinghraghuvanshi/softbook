export interface IResponse {
  movie: IMovie;
  counter: number;
}
