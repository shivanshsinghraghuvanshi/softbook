import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'softbook-exception',
  templateUrl: './exception.component.html',
  styleUrls: ['./exception.component.scss']
})
export class ExceptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
