# softbook

A sample online book renting application to learn Angular with AWS aplify
